package net.simplifiedcoding.firebasecloudmessaging;

/**
 *
 */

public class EndPoints {
    //https://qvayaapp.000webhostapp.com/Thando/pushNotification/sendSinglePush.php
    //https://barcodescanner.000webhostapp.com/sendSinglePush.php
   public static final String URL_REGISTER_DEVICE =    "https://qvayaapp.000webhostapp.com/Thando/pushNotification/RegisterDevice.php";
    public static final String URL_SEND_SINGLE_PUSH =   "https://qvayaapp.000webhostapp.com/Thando/pushNotification/sendSinglePush.php";
    public static final String URL_SEND_MULTIPLE_PUSH = "https://qvayaapp.000webhostapp.com/Thando/pushNotification/sendMultiplePush.php";
    public static final String URL_FETCH_DEVICES =      "https://qvayaapp.000webhostapp.com/Thando/pushNotification/GetRegisteredDevices.php";
    /*public static final String URL_REGISTER_DEVICE =    "https://barcodescanner.000webhostapp.com/RegisterDevice.php";
    public static final String URL_SEND_SINGLE_PUSH =   "https://barcodescanner.000webhostapp.com/sendSinglePush.php";
    public static final String URL_SEND_MULTIPLE_PUSH = "https://barcodescanner.000webhostapp.com/sendMultiplePush.php";
    public static final String URL_FETCH_DEVICES =      "https://barcodescanner.000webhostapp.com/GetRegisteredDevices.php";*/
}